99% of the wallpapers are not mine!
Thank you for downloading the wallpaper package from domicki.ga!